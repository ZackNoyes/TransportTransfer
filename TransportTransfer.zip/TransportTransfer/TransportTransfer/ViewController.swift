//
//  ViewController.swift
//  TransportTransfer
//
//  Created by Zack Noyes on 29/7/17.
//  Copyright © 2017 Zack Noyes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	var task: URLSessionDataTask!

	
	@IBOutlet weak var timeLabel: UILabel!
	@IBOutlet weak var originField: UITextField!
	@IBOutlet weak var destinationField: UITextField!

	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.



	}

	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		let destination = segue.destination as! TableViewController
		destination.origin = originField.text
		destination.destination = destinationField.text

	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

