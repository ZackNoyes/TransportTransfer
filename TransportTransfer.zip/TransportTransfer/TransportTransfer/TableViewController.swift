//
//  TableViewController.swift
//  TransportTransfer
//
//  Created by Zack Noyes on 30/7/17.
//  Copyright © 2017 Zack Noyes. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

	var origin: String!
	var destination: String!

	@IBOutlet weak var originLabel: UILabel!
	@IBOutlet weak var destinationLabel: UILabel!
	@IBOutlet weak var drivingTimeLabel: UILabel!
	@IBOutlet weak var cyclingTimeLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
		originLabel.text = origin
		destinationLabel.text = destination

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
		updateLabel()
    }

	func updateLabel() {

		let originFieldText: String = origin


		let url2 = URL(string: "https://maps.googleapis.com/maps/api/geocode/json?address=\(originFieldText)&key=AIzaSyBoNHPRodpp6x_OJiCcbY1nDcJbuaeIuv8".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)

		var lat: Double = 0
		var long: Double = 0

		let task2 = URLSession.shared.dataTask(with: url2!) { (data, response, error) in
			do {
				let json = try JSONSerialization.jsonObject(with: data!, options:	JSONSerialization.ReadingOptions.mutableContainers) as! [String: AnyObject]
				let results = json["results"] as! [[String: AnyObject]]
				let result = results[0]
				let geometry = result["geometry"] as! [String: AnyObject]
				let location = geometry["location"] as! [String: Double]
				lat = location["lat"]!
				long = location["lng"]!

			} catch {

			}
		}
		task2.resume()

		print(lat)
		print(long)
		var buslocations: [(Double, Double)] = []
		do {
			let data = try Data(contentsOf: URL(fileURLWithPath: Bundle.main.path(forResource: "busStopLocations", ofType: "json")!))
			let busJson = try JSONSerialization.jsonObject(with: data, options:	JSONSerialization.ReadingOptions.mutableContainers) as! [String: AnyObject]
			let jdata = busJson["data"] as! [[AnyObject]]

			for array in jdata {
					let lat = 2.0
					let long = 2.0
					buslocations.append((lat, long))
			}

			print(buslocations)
		} catch {

		}






		let destinationFieldText: String = destination
		if originFieldText != "" && destinationFieldText != "" {
			let url = URL(string: "https://maps.googleapis.com/maps/api/distancematrix/json?origins=\(originFieldText)&destinations=\(destinationFieldText)&key=AIzaSyBoNHPRodpp6x_OJiCcbY1nDcJbuaeIuv8&mode=driving".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
			let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
				if error != nil {
					print("ERROR")
				} else {
					if let content = data {
						do {
							let json = try JSONSerialization.jsonObject(with: content, options:	JSONSerialization.ReadingOptions.mutableContainers) as! [String: AnyObject]

							let destinationAddresses = json["destination_addresses"] as! [String]
							let destinationAddress = destinationAddresses[0]


							let originAddresses = json["origin_addresses"] as! [String]
							let originAddress = originAddresses[0]

							DispatchQueue.main.async {
								self.destinationLabel.text = destinationAddress
								self.originLabel.text = originAddress
							}

							let rows = json["rows"] as! [AnyObject]
							let route = rows[0] as! [String: AnyObject]
							let elements = route["elements"] as! [AnyObject]
							let element = elements[0]



							if let duration = element["duration"] as? [String: AnyObject] {
								let text = duration["text"] as! String
								print(text)
								DispatchQueue.main.async {
									self.drivingTimeLabel.text = text
								}
							} else {
								DispatchQueue.main.async {
									self.drivingTimeLabel.text = "No Results"
								}
							}

							if let distance = element["distance"] as? [String: AnyObject] {
								let value = distance["value"] as! Int
								let kilometers = value/1000
								let time = kilometers*4 + 4
								DispatchQueue.main.async {
									self.cyclingTimeLabel.text = String(time) + " min"
								}
							} else {
								DispatchQueue.main.async {
									self.cyclingTimeLabel.text = "No Results"
								}
							}

						} catch {

						}
					}
				}
			}
			task.resume()
		}
		
	}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

       /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
